/**
 * ==========================================================================
 * EL ARTE DEL DIORAMA - LÓGICA INTERACTIVA Y SIMULADOR DE CAPAS
 * ==========================================================================
 */

// 1. Datos completos de las capas del Diorama
const DIORAMA_LAYERS = [
  {
    id: 0,
    name: "01. Base y Marco de Madera",
    shortName: "Marco y Base",
    category: "Cimiento Estructural",
    difficulty: "Fácil (1/5)",
    materials: "Tablero DM/MDF de 15mm, moldura de madera de nogal o pino, masilla para madera, barniz satinado.",
    tools: "Sierra de inglete, sargentos de carpintero, lija de grano fino (240 y 400), cola de carpintero.",
    time: "2 a 3 horas (+ 12h de secado del barniz)",
    description: "El punto de partida fundamental. Una base rígida e indeformable previene que el diorama se combe con la humedad de las colas y escayolas posteriores. El marco perimetral protege los bordes y da la terminación de obra de arte de museo.",
    proTip: "Pinta o barniza el marco antes de empezar la escenografía y protégelo con cinta de carrocero de alta calidad para no mancharlo con pintura o pegamentos.",
    svgId: "layer-svg-0"
  },
  {
    id: 1,
    name: "02. Topografía y Núcleo de Relieve",
    shortName: "Relieve XPS",
    category: "Geometría del Terreno",
    difficulty: "Intermedio (2/5)",
    materials: "Poliestireno extruido (XPS de alta densidad, color azul o rosa) de 20-40mm de grosor.",
    tools: "Cúter olfa de hoja ancha, cortador de hilo caliente, cepillo de cerdas metálicas, lija gruesa (grano 80).",
    time: "3 a 5 horas",
    description: "Creación del relieve topográfico: colinas campesinas, desniveles de caminos de tierra, zanjas y pendientes naturales. El XPS no se deforma, no absorbe agua y permite tallar formas orgánicas con extraordinaria precisión.",
    proTip: "Nunca uses poliestireno expandido blanco (corcho blanco de bolitas), ya que se desmenuza. Pasa un cepillo de alambre sobre el XPS tallado para crear micro-arrugas que anclan la masilla.",
    svgId: "layer-svg-1"
  },
  {
    id: 2,
    name: "03. Texturizado y Estrato de Tierra",
    shortName: "Tierra y Textura",
    category: "Suelo Orgánico",
    difficulty: "Intermedio (2/5)",
    materials: "Tierra real tamizada (grano fino y medio), escayola o Sculptamold, cola blanca (PVA), cortezas de pino (para rocas).",
    tools: "Tamiz de cocina de varios pasos, espátula de modelar, pincel plano viejo, pulverizador fino.",
    time: "4 horas (+ 24h de secado)",
    description: "La capa que aporta verosimilitud física al terreno. Se aplica una pasta de escayola mezclada con cola y se espolvorean tierras reales horneadas para eliminar materia orgánica y bacterias.",
    proTip: "Para fijar la tierra espolvoreada sin moverla, rocía primero alcohol isopropílico con atomizador (rompe la tensión superficial) y luego gotea cola blanca diluida 50/50 con agua.",
    svgId: "layer-svg-2"
  },
  {
    id: 3,
    name: "04. Imprimación y Pintura Base",
    shortName: "Pintura y Sombras",
    category: "Colorimetría y Luces",
    difficulty: "Avanzado (3/5)",
    materials: "Pinturas acrílicas mate (Tierra sombra tostada, ocre, verde oliva, gris piedra), tintas y lavados.",
    tools: "Aerógrafo con boquilla 0.3mm o pinceles planos de pelo suave, pincel seco para resaltar aristas.",
    time: "3 a 4 horas",
    description: "Bloqueo cromático del suelo. Se establece una imprimación oscura en las grietas y desniveles para crear volumen y profundidad, seguida de tonos tierra cálidos y luces cenitales en las crestas y zonas expuestas.",
    proTip: "Evita siempre los negros puros. Utiliza tonos tierra de sombra tostada o marrón chocolate oscuro para las sombras más profundas; lucirá mucho más natural.",
    svgId: "layer-svg-3"
  },
  {
    id: 4,
    name: "05. Arquitectura Rural Campesina",
    shortName: "Estructuras Rústicas",
    category: "Edificaciones y Elementos",
    difficulty: "Avanzado (4/5)",
    materials: "Madera de balsa y tilo, cartón pluma desprovisto de papel, pasta das para muros de piedra, alambre de latón.",
    tools: "Regla metálica, bisturí de precisión número 11, punzón para marcar vetas de madera, cianocrilato.",
    time: "8 a 15 horas",
    description: "Construcción a escala de la casa rústica, el pozo de piedra y las vallas de madera envejecida. Las tablas de balsa se rayan con cepillo de alambre para simular la veta de madera azotada por el clima.",
    proTip: "Para envejecer la madera virgen al instante, sumérgela en una solución casera de vinagre blanco macerado durante 24 horas con lana de acero fina. Adquiere un tono gris ceniza centenario.",
    svgId: "layer-svg-4"
  },
  {
    id: 5,
    name: "06. Vegetación Base y Suelo Flocado",
    shortName: "Césped y Pradera",
    category: "Manto Vegetal",
    difficulty: "Intermedio (3/5)",
    materials: "Césped electrostático de 2mm y 4mm (tonos verde oscuro, seco y paja), cola especial de césped o cola blanca.",
    tools: "Aplicador electrostático de hierba (hierba estática), pinzas de precisión, aspirador con media protectora.",
    time: "3 horas",
    description: "El césped electrostático se polariza mediante una carga estática que hace que las fibras microscópicas caigan verticalmente de pie sobre la cola, simulando briznas de hierba realistas en lugar de césped aplastado.",
    proTip: "Combina siempre al menos 3 tonos distintos de césped (verde oscuro en zonas húmedas, beige en zonas de paso pisoteadas y marrón en bordes de caminos). La naturaleza nunca es monocromática.",
    svgId: "layer-svg-5"
  },
  {
    id: 6,
    name: "07. Follaje Alto, Arbustos y Huerto",
    shortName: "Árboles y Cultivos",
    category: "Flora Tridimensional",
    difficulty: "Avanzado (4/5)",
    materials: "Alambre de cobre trenzado para troncos, masilla epoxy, musgo natural (teloxys aristata), flocado de esponja microscópica.",
    tools: "Soldador o alicates de corte, aerógrafo, laca para fijar follaje, micropinzas.",
    time: "6 a 8 horas",
    description: "Construcción del árbol frutal campesino y el huerto con calabazas y repollos en miniatura. Las ramas se retuercen desde el tronco para formar copas orgánicas y se visten con hojas micro-troqueladas a escala.",
    proTip: "Usa raíces secas de plantas reales como esqueleto para las ramas más finas: su ramificación fractal natural es imposible de replicar a mano con tanta perfección.",
    svgId: "layer-svg-6"
  },
  {
    id: 7,
    name: "08. Micro-detalles, Figuras y Weathering",
    shortName: "Vida y Pátinas",
    category: "Narrativa y Realismo",
    difficulty: "Maestría (5/5)",
    materials: "Pigmentos en polvo (polvo de camino, hollín, óxido), resina epoxi bicomponente para charcos, figuras a escala.",
    tools: "Pinceles números 000 y 00, fijador de pigmentos mate, jeringuilla dosificadora para la resina.",
    time: "5 a 10 horas",
    description: "La capa que cuenta la historia: la figura del campesino con su azadón, la carretilla cargada con paja, las gallinas picoteando en el corral, el agua cristalina acumulada en los surcos del camino y el polvo acumulado en la base de los muros.",
    proTip: "Aplica los pigmentos de polvo siempre en seco al final y séllalos con fijador de pigmentos específico o 'white spirit' suave para que no pierdan su acabado mate aterciopelado.",
    svgId: "layer-svg-7"
  }
];

// Estado global de la aplicación
const AppState = {
  currentTab: 'inicio',
  activeLayers: [0, 1, 2, 3, 4, 5, 6, 7], // Todas visibles por defecto
  selectedLayerId: 0,
  isExplodedView: false,
  scaleCalculator: {
    realValue: 1.75, // 1.75 metros (altura estándar persona)
    scaleRatio: 35   // 1:35
  },
  checklist: {}
};

// ==========================================================================
// 2. INICIALIZACIÓN Y NAVEGACIÓN (SPA + Google Sites Safe)
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initSimulator();
  initScaleCalculator();
  initChecklist();
  initFaqAccordion();
  initGoogleSitesModal();

  // Comprobar si hay hash en la URL (ej: #capas o #proceso)
  const initialHash = window.location.hash.replace('#', '');
  if (initialHash && ['inicio', 'capas', 'proceso'].includes(initialHash)) {
    switchTab(initialHash);
  }
});

function initNavigation() {
  const tabButtons = document.querySelectorAll('.nav-tab-btn');
  tabButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const targetTab = btn.getAttribute('data-tab');
      if (targetTab) {
        switchTab(targetTab);
      }
    });
  });

  // Enlaces con atributo data-jump-tab
  document.querySelectorAll('[data-jump-tab]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const tab = el.getAttribute('data-jump-tab');
      if (tab) switchTab(tab);
    });
  });
}

function switchTab(tabId) {
  AppState.currentTab = tabId;

  // Actualizar botones de navegación
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Actualizar vistas
  document.querySelectorAll('.tab-view').forEach(view => {
    if (view.id === `view-${tabId}`) {
      view.classList.add('active');
    } else {
      view.classList.remove('active');
    }
  });

  // Actualizar hash de forma segura
  try {
    history.replaceState(null, null, `#${tabId}`);
  } catch (err) {
    // Si está en un iframe restrictivo de Google Sites
  }

  // Scroll suave al inicio del contenido
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==========================================================================
// 3. SIMULADOR INTERACTIVO DE CAPAS
// ==========================================================================

function initSimulator() {
  renderLayerSelector();
  renderLayerDetails(AppState.selectedLayerId);
  setupSimulatorControls();
  updateSimulatorVisuals();
}

function renderLayerSelector() {
  const container = document.getElementById('layerSelectorContainer');
  if (!container) return;

  container.innerHTML = DIORAMA_LAYERS.map(layer => {
    const isVisible = AppState.activeLayers.includes(layer.id);
    const isSelected = AppState.selectedLayerId === layer.id;

    return `
      <div class="layer-item-row ${isSelected ? 'active' : ''}" data-layer-id="${layer.id}">
        <div class="layer-left-info">
          <div class="layer-badge-num">${layer.id + 1}</div>
          <span class="layer-title-text">${layer.shortName}</span>
        </div>
        <div class="layer-toggle-switch ${isVisible ? 'on' : ''}" data-toggle-id="${layer.id}" title="Alternar visibilidad"></div>
      </div>
    `;
  }).join('');

  // Eventos de selección de capa y switch de visibilidad
  container.querySelectorAll('.layer-item-row').forEach(row => {
    row.addEventListener('click', (e) => {
      const layerId = parseInt(row.getAttribute('data-layer-id'), 10);
      
      // Si el clic fue en el switch, alternar visibilidad
      if (e.target.classList.contains('layer-toggle-switch') || e.target.closest('.layer-toggle-switch')) {
        toggleLayerVisibility(layerId);
      } else {
        selectLayer(layerId);
      }
    });
  });
}

function selectLayer(layerId) {
  AppState.selectedLayerId = layerId;
  
  // Si la capa seleccionada estaba oculta, activarla para poder apreciarla
  if (!AppState.activeLayers.includes(layerId)) {
    AppState.activeLayers.push(layerId);
    AppState.activeLayers.sort((a, b) => a - b);
  }

  // Actualizar UI
  document.querySelectorAll('.layer-item-row').forEach(row => {
    const id = parseInt(row.getAttribute('data-layer-id'), 10);
    row.classList.toggle('active', id === layerId);
  });

  renderLayerDetails(layerId);
  updateSimulatorVisuals();
}

function toggleLayerVisibility(layerId) {
  const index = AppState.activeLayers.indexOf(layerId);
  if (index > -1) {
    // Si ya está activa, desactivarla (mínimo 1 capa activa)
    if (AppState.activeLayers.length > 1) {
      AppState.activeLayers.splice(index, 1);
    }
  } else {
    AppState.activeLayers.push(layerId);
    AppState.activeLayers.sort((a, b) => a - b);
  }

  // Actualizar slider acumulativo
  const maxActive = Math.max(...AppState.activeLayers, 0);
  const slider = document.getElementById('layerScrubberSlider');
  if (slider) slider.value = maxActive + 1;

  renderLayerSelector();
  updateSimulatorVisuals();
}

function renderLayerDetails(layerId) {
  const layer = DIORAMA_LAYERS.find(l => l.id === layerId) || DIORAMA_LAYERS[0];
  const container = document.getElementById('layerDetailContainer');
  if (!container) return;

  container.innerHTML = `
    <div class="detail-layer-tag">
      <span class="brand-subtitle" style="color: var(--moss-light); font-weight:700;">CAPA ${layer.id + 1} DE 8 &bull; ${layer.category.toUpperCase()}</span>
      <span class="detail-badge-diff">${layer.difficulty}</span>
    </div>
    <h3 class="detail-layer-title">${layer.name}</h3>
    <p class="detail-description">${layer.description}</p>
    
    <div class="detail-specs-grid">
      <div class="detail-spec-box">
        <label>Materiales Principales</label>
        <span>${layer.materials}</span>
      </div>
      <div class="detail-spec-box">
        <label>Herramientas Clave</label>
        <span>${layer.tools}</span>
      </div>
      <div class="detail-spec-box">
        <label>Tiempo Estimado</label>
        <span>${layer.time}</span>
      </div>
      <div class="detail-spec-box">
        <label>Objetivo Estético</label>
        <span>${layer.shortName} con realismo a escala</span>
      </div>
    </div>

    <div class="pro-tip-box">
      <strong>Consejo del Maestro Modelista</strong>
      ${layer.proTip}
    </div>
  `;
}

function setupSimulatorControls() {
  // Slider acumulativo
  const slider = document.getElementById('layerScrubberSlider');
  const prevBtn = document.getElementById('scrubberPrevBtn');
  const nextBtn = document.getElementById('scrubberNextBtn');

  if (slider) {
    slider.addEventListener('input', (e) => {
      const step = parseInt(e.target.value, 10); // 1 a 8
      setCumulativeLayers(step);
    });
  }

  if (prevBtn && slider) {
    prevBtn.addEventListener('click', () => {
      let val = parseInt(slider.value, 10) - 1;
      if (val < 1) val = 1;
      slider.value = val;
      setCumulativeLayers(val);
    });
  }

  if (nextBtn && slider) {
    nextBtn.addEventListener('click', () => {
      let val = parseInt(slider.value, 10) + 1;
      if (val > 8) val = 8;
      slider.value = val;
      setCumulativeLayers(val);
    });
  }

  // Modos de vista: Normal vs Explosionada
  const btnNormal = document.getElementById('btnViewNormal');
  const btnExploded = document.getElementById('btnViewExploded');

  if (btnNormal && btnExploded) {
    btnNormal.addEventListener('click', () => {
      AppState.isExplodedView = false;
      btnNormal.classList.add('active');
      btnExploded.classList.remove('active');
      updateSimulatorVisuals();
    });

    btnExploded.addEventListener('click', () => {
      AppState.isExplodedView = true;
      btnExploded.classList.add('active');
      btnNormal.classList.remove('active');
      updateSimulatorVisuals();
    });
  }

  // Botón mostrar todas / ocultar
  const toggleAllBtn = document.getElementById('btnToggleAllLayers');
  if (toggleAllBtn) {
    toggleAllBtn.addEventListener('click', () => {
      if (AppState.activeLayers.length === 8) {
        AppState.activeLayers = [0]; // dejar solo la base
      } else {
        AppState.activeLayers = [0, 1, 2, 3, 4, 5, 6, 7];
      }
      renderLayerSelector();
      updateSimulatorVisuals();
    });
  }
}

function setCumulativeLayers(step) {
  // step es de 1 a 8
  AppState.activeLayers = [];
  for (let i = 0; i < step; i++) {
    AppState.activeLayers.push(i);
  }
  selectLayer(step - 1);
  renderLayerSelector();
  updateSimulatorVisuals();
}

function updateSimulatorVisuals() {
  // Actualizar contador
  const counterEl = document.getElementById('activeLayersCounter');
  if (counterEl) {
    counterEl.textContent = `${AppState.activeLayers.length} de 8 Capas Activas`;
  }

  // Actualizar capas en el gráfico SVG
  for (let i = 0; i < 8; i++) {
    const svgLayer = document.getElementById(`diorama-svg-layer-${i}`);
    if (!svgLayer) continue;

    const isVisible = AppState.activeLayers.includes(i);
    const isSelected = AppState.selectedLayerId === i;

    // Visibilidad
    if (isVisible) {
      svgLayer.classList.remove('hidden-layer');
    } else {
      svgLayer.classList.add('hidden-layer');
    }

    // Resaltado de selección
    if (isSelected && isVisible) {
      svgLayer.classList.add('highlighted-layer');
    } else {
      svgLayer.classList.remove('highlighted-layer');
    }

    // Efecto de vista explosionada (Exploded View): desplaza capas en el eje vertical
    if (AppState.isExplodedView && isVisible) {
      // Cada capa superior se eleva más en Y
      const offsetExplodedY = -(i * 24);
      svgLayer.style.transform = `translateY(${offsetExplodedY}px)`;
    } else {
      svgLayer.style.transform = 'translateY(0px)';
    }
  }

  // Ajustar escala global del contenedor si está en modo explosionado para que no se corte
  const svgWrap = document.querySelector('.diorama-interactive-svg-wrap');
  if (svgWrap) {
    if (AppState.isExplodedView) {
      svgWrap.style.transform = 'translateY(55px) scale(0.88)';
    } else {
      svgWrap.style.transform = 'translateY(0px) scale(1)';
    }
  }
}

// ==========================================================================
// 4. CALCULADORA DE ESCALAS DE MODELISMO
// ==========================================================================

function initScaleCalculator() {
  const realInput = document.getElementById('calcRealSizeInput');
  const unitSelect = document.getElementById('calcUnitSelect');
  const scaleButtons = document.querySelectorAll('.scale-btn');
  const customInput = document.getElementById('calcCustomScaleInput');

  function calculate() {
    const realVal = parseFloat(realInput.value) || 0;
    const unit = unitSelect ? unitSelect.value : 'm';
    const scaleRatio = AppState.scaleCalculator.scaleRatio;

    // Convertir a milímetros reales
    let realMm = realVal * 1000;
    if (unit === 'cm') realMm = realVal * 10;
    if (unit === 'mm') realMm = realVal;

    // Calcular tamaño a escala
    const scaleMm = realMm / scaleRatio;
    const scaleCm = scaleMm / 10;

    const valEl = document.getElementById('calcResultValue');
    const subEl = document.getElementById('calcResultSub');

    if (valEl) {
      if (scaleMm >= 100) {
        valEl.textContent = `${scaleCm.toFixed(1)} cm`;
      } else {
        valEl.textContent = `${scaleMm.toFixed(1)} mm`;
      }
    }

    if (subEl) {
      subEl.innerHTML = `Equivale a <strong>${scaleMm.toFixed(2)} mm</strong> en tu diorama (Escala 1:${scaleRatio})`;
    }
  }

  if (realInput) realInput.addEventListener('input', calculate);
  if (unitSelect) unitSelect.addEventListener('change', calculate);

  scaleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      scaleButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const ratio = parseInt(btn.getAttribute('data-scale'), 10);
      AppState.scaleCalculator.scaleRatio = ratio;
      if (customInput) customInput.value = ratio;
      calculate();
    });
  });

  if (customInput) {
    customInput.addEventListener('input', () => {
      const val = parseInt(customInput.value, 10);
      if (val > 0) {
        scaleButtons.forEach(b => b.classList.remove('active'));
        AppState.scaleCalculator.scaleRatio = val;
        calculate();
      }
    });
  }

  calculate();
}

// ==========================================================================
// 5. CHECKLIST INTERACTIVO DE MATERIALES CON PROGRESO
// ==========================================================================

const DEFAULT_CHECKLIST_ITEMS = [
  { id: 'mat1', name: 'Base de madera DM / Marco de moldura', category: 'Base' },
  { id: 'mat2', name: 'Plancha de Poliestireno Extruido (XPS)', category: 'Base' },
  { id: 'mat3', name: 'Cola de carpintero y Cola blanca PVA', category: 'Pegamentos' },
  { id: 'mat4', name: 'Cianocrilato (Super Glue líquido y gel)', category: 'Pegamentos' },
  { id: 'mat5', name: 'Tierra natural tamizada y piedras a escala', category: 'Terreno' },
  { id: 'mat6', name: 'Escayola de secado lento o masilla Sculptamold', category: 'Terreno' },
  { id: 'mat7', name: 'Pinturas acrílicas mate (Tierra, Ocre, Verdes, Grises)', category: 'Pintura' },
  { id: 'mat8', name: 'Lavados acrílicos y pigmentos de intemperie (polvo/óxido)', category: 'Pintura' },
  { id: 'mat9', name: 'Listones y tableros de madera de balsa', category: 'Construcción' },
  { id: 'mat10', name: 'Césped electrostático (varias medidas 2mm - 4mm)', category: 'Vegetación' },
  { id: 'mat11', name: 'Musgo marino (Teloxys) o alambre para árboles', category: 'Vegetación' },
  { id: 'mat12', name: 'Alcohol isopropílico en spray (rompedor de tensión)', category: 'Herramientas' },
  { id: 'mat13', name: 'Cúter bisturí con cuchillas nuevas nº 11', category: 'Herramientas' },
  { id: 'mat14', name: 'Figuras campesinas y aperos a escala elegida', category: 'Detalles' }
];

function initChecklist() {
  const container = document.getElementById('checklistContainer');
  if (!container) return;

  // Cargar estado desde localStorage si está disponible
  try {
    const saved = localStorage.getItem('diorama_checklist');
    if (saved) AppState.checklist = JSON.parse(saved);
  } catch (e) {}

  container.innerHTML = DEFAULT_CHECKLIST_ITEMS.map(item => {
    const isChecked = !!AppState.checklist[item.id];
    return `
      <label class="check-item-label ${isChecked ? 'checked' : ''}" data-item-id="${item.id}">
        <input type="checkbox" ${isChecked ? 'checked' : ''}>
        <span class="check-item-text">${item.name}</span>
        <span class="check-category-pill">${item.category}</span>
      </label>
    `;
  }).join('');

  container.querySelectorAll('.check-item-label').forEach(label => {
    const checkbox = label.querySelector('input[type="checkbox"]');
    checkbox.addEventListener('change', () => {
      const itemId = label.getAttribute('data-item-id');
      AppState.checklist[itemId] = checkbox.checked;
      label.classList.toggle('checked', checkbox.checked);

      try {
        localStorage.setItem('diorama_checklist', JSON.stringify(AppState.checklist));
      } catch (e) {}

      updateChecklistProgress();
    });
  });

  updateChecklistProgress();
}

function updateChecklistProgress() {
  const total = DEFAULT_CHECKLIST_ITEMS.length;
  const checked = Object.values(AppState.checklist).filter(Boolean).length;
  const percentage = Math.round((checked / total) * 100);

  const fillEl = document.getElementById('checklistFill');
  const countEl = document.getElementById('checklistCount');
  const percentEl = document.getElementById('checklistPercent');

  if (fillEl) fillEl.style.width = `${percentage}%`;
  if (countEl) countEl.textContent = `${checked} de ${total} materiales listos`;
  if (percentEl) percentEl.textContent = `${percentage}%`;
}

// ==========================================================================
// 6. ACORDEÓN DE ERRORES FRECUENTES Y SOLUCIONES
// ==========================================================================

function initFaqAccordion() {
  const items = document.querySelectorAll('.faq-item');
  items.forEach(item => {
    const header = item.querySelector('.faq-header');
    if (header) {
      header.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        // Cerrar los demás
        items.forEach(i => i.classList.remove('open'));
        if (!isOpen) {
          item.classList.add('open');
        }
      });
    }
  });
}

// ==========================================================================
// 7. MODAL DE ASISTENCIA PARA GOOGLE SITES
// ==========================================================================

function initGoogleSitesModal() {
  const modal = document.getElementById('googleSitesModal');
  const openButtons = document.querySelectorAll('[data-open-modal="googleSites"]');
  const closeButton = document.getElementById('closeModalBtn');
  const copyBtn = document.getElementById('copyIframeBtn');

  openButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (modal) modal.classList.add('active');
    });
  });

  if (closeButton && modal) {
    closeButton.addEventListener('click', () => {
      modal.classList.remove('active');
    });
  }

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('active');
    });
  }

  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const codeSnippet = document.getElementById('iframeCodeSnippet');
      if (codeSnippet) {
        navigator.clipboard.writeText(codeSnippet.textContent).then(() => {
          const originalText = copyBtn.innerHTML;
          copyBtn.innerHTML = `✓ ¡Código Copiado!`;
          setTimeout(() => {
            copyBtn.innerHTML = originalText;
          }, 2500);
        });
      }
    });
  }
}
